/*
	skyeye_uart.c - skyeye uart device support functions
	Copyright (C) 2003 - 2007 Skyeye Develop Group
	for help please send mail to <skyeye-developer@lists.gro.clinux.org>

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
*/

/*
 * 2007.01.18	by Anthony Lee : initial version
 */

#include "skyeye_config.h"
#include "skyeye_options.h"
#include "skyeye_mm.h"
#include "skyeye_uart_ops.h"

#include "skyeye_uart.h"

#include "portable/gettimeofday.h"
//#include "portable/usleep.h"

struct uart_converter
{
	char name[MAX_STR_NAME];
	void (*setup)(struct uart_device *uart_dev);
};


static struct uart_converter uart_cvts[] = {
	/* name		setup */
	{ "dcc",	skyeye_uart_converter_dcc_setup },
	{ "",		NULL },
};

static int skyeye_uart_stdio_once_flag = 0;

static int
do_uart_option (skyeye_option_t * this_option, int num_params,
		const char *params[]);
static int skyeye_uart_check_timeout(struct timeval *tv)
{
	struct timeval cur_time;

	if (tv == NULL) return 1;
	if (gettimeofday(&cur_time, NULL) != 0) return -1;

	if (cur_time.tv_sec > tv->tv_sec) return 0;
	if (cur_time.tv_sec == tv->tv_sec && cur_time.tv_usec >= tv->tv_usec) return 0;

	return 1;
}


int uart_read(int devIndex, void *buf, size_t count, struct timeval *timeout, int *retDevIndex)
{
	int retVal = -1;
	struct uart_device *uart_dev;
	skyeye_config_t* config;
	config = get_current_config();

	if (retDevIndex != NULL) *retDevIndex = -1;

	if (devIndex >= config->uart.count || buf == NULL || count == 0) { /* invalid */
	} else if(devIndex >= 0) { /* single device */
		uart_dev = config->uart.devs[devIndex];
		retVal = uart_dev->uart_read(uart_dev, buf, count, timeout);
	} else { /* all devices */
		int i, stop_flags = 0;
		struct timeval tv, zero_tv;

		if (!(timeout == NULL || gettimeofday(&tv, NULL) == 0)) { /* something error */
		} else {
			if (timeout != NULL) {
				tv.tv_sec += (timeout->tv_sec + (timeout->tv_usec + tv.tv_usec) / 1000000UL);
				tv.tv_usec = (timeout->tv_usec + tv.tv_usec) % 1000000UL;
			}

			zero_tv.tv_sec = 0;
			zero_tv.tv_usec = 0;

			do {
				for (i = 0; i < config->uart.count; i++) {
					uart_dev = config->uart.devs[i];
					retVal = uart_dev->uart_read(uart_dev, buf, count, &zero_tv);

					if(retVal > 0) { /* got something */
						devIndex = i;
						break;
					}
					if(retVal == 0) continue;
					stop_flags |= (1 << i); /* failed */
				}

				if (stop_flags == (1 << config->uart.count) - 1) { /* all failed */
					retVal = -1;
				} else if (retVal > 0) {
					stop_flags = 1;
				} else {
					retVal = 0;

					if (skyeye_uart_check_timeout(timeout != NULL ? &tv : NULL) == 1) { /* polling */
						stop_flags = 0;
						usleep(500);
					} else { /* timeout */
						stop_flags = 1;
					}
				}
			} while (stop_flags == 0);
		}
	}

	if (retVal > 0 && retDevIndex != NULL) *retDevIndex = devIndex;

	return retVal;
}


int uart_write(int devIndex, void *buf, size_t count, int *wroteBytes[MAX_UART_DEVICE_NUM])
{
	skyeye_config_t* config = get_current_config();
	int i = (devIndex < 0 ? config->uart.count - 1 : devIndex);
	int retVal = -1;
	int nWrote = 0;

	if (i < 0 || i >= config->uart.count) return -1;

	do {
		nWrote = config->uart.devs[i]->uart_write(config->uart.devs[i], buf, count);
		if (wroteBytes != NULL) (*wroteBytes)[i] = nWrote;
		retVal = max(retVal, nWrote);
	} while (--i >= 0 && devIndex < 0);

	return retVal;
}


/* skyeye_uart_cleanup(): for cleanup stack on exit */
void skyeye_uart_cleanup()
{
	skyeye_config_t* config = get_current_config();
	int i = config->uart.count;
	struct uart_device *dev;

	config->uart.count = 0;
	while (--i >= 0) {
		dev = config->uart.devs[i];
		dev->uart_close(dev);
		free(dev);
	}
}


/* 
 * skyeye_uart_setup(): setup device when analyzing uart options 
 */
int skyeye_uart_setup(struct uart_option *uart_opt)
{
	struct uart_device *uart_dev;
	int ret = -1;
	skyeye_config_t* config = get_current_config();

	if (config->uart.count >= MAX_UART_DEVICE_NUM) return -1;

	uart_dev = (struct uart_device *)malloc(sizeof(struct uart_device));
	if (uart_dev == NULL) return -1;

	memset(uart_dev, 0, sizeof(struct uart_device));

	uart_dev->mod = uart_opt->mod;
	memcpy(&uart_dev->desc_in[0], &uart_opt->desc_in[0], MAX_STR_NAME);
	memcpy(&uart_dev->desc_out[0], &uart_opt->desc_out[0], MAX_STR_NAME);
	memcpy(&uart_dev->converter[0], &uart_opt->converter[0], MAX_STR_NAME);

	SKYEYE_INFO("uart_mod:%d, desc_in:%s, desc_out:%s, converter:%s\n",
	       uart_dev->mod, uart_dev->desc_in, uart_dev->desc_out, uart_dev->converter);

	switch (uart_dev->mod) {
		case UART_SIM_STDIO:
			if (skyeye_uart_stdio_once_flag != 0) break;
			uart_dev->uart_open = uart_stdio_open;
			uart_dev->uart_close = uart_stdio_close;
			uart_dev->uart_read = uart_stdio_read;
			uart_dev->uart_write = uart_stdio_write;
			ret = 0;
			break;

		case UART_SIM_PIPE:
			uart_dev->uart_open = uart_pipe_open;
			uart_dev->uart_close = uart_pipe_close;
			uart_dev->uart_read = uart_pipe_read;
			uart_dev->uart_write = uart_pipe_write;
			ret = 0;
			break;

		case UART_SIM_NET:
			uart_dev->uart_open = uart_net_open;
			uart_dev->uart_close = uart_net_close;
			uart_dev->uart_read = uart_net_read;
			uart_dev->uart_write = uart_net_write;
			ret = 0;
			break;
		case UART_SIM_TERM:
			uart_dev->uart_open = uart_term_open;
			uart_dev->uart_close = uart_term_close;
			uart_dev->uart_read = uart_term_read;
			uart_dev->uart_write = uart_term_write;
			ret = 0;
			break;
		default:
			break;
	}

	if (ret == 0) {
		if(uart_dev->uart_open(uart_dev) == 0) {
			config->uart.devs[config->uart.count++] = uart_dev;
			if(uart_dev->mod == UART_SIM_STDIO) skyeye_uart_stdio_once_flag = 1;
		} else {
			ret = -1;
		}
	}

	if (ret != 0) {
		free(uart_dev);
		uart_dev = NULL;
	}

	return ret;
}

/* skyeye_uart_converter_setup(): setup converter of uart devices after machine initalized */
void skyeye_uart_converter_setup(void)
{
	struct uart_device *uart_dev;
	int i, k;
	skyeye_config_t* config = get_current_config();

	for (i = 0; i < config->uart.count; i++) {
		uart_dev = config->uart.devs[i];
		if (uart_dev->converter[0] == 0) continue;

		for (k = 0; uart_cvts[k].setup != NULL; k++) {
			if (strncmp(&uart_dev->converter[0], &uart_cvts[k].name[0], MAX_STR_NAME) == 0) {
					(*(uart_cvts[k].setup))(uart_dev);
			}
		}
	}
}
/*uart option*/
int
do_uart_option (skyeye_option_t * this_option, int num_params,
		const char *params[])
{
	char name[MAX_PARAM_NAME], value[MAX_PARAM_NAME];

	/* 2007-01-18 added by Anthony Lee: for new uart device frame */
	/* At default, if none options for uart were found,
	 * the function named "skyeye_read_config()" from "utils/config/skyeye_config.c" would insert
	 * a blank line in order to call this to make the uart simulation by standard input/output.
	 */
	struct uart_option uart_opt = {"", "", UART_SIM_STDIO, ""};
	int i, only_desc = 0;

	for (i = 0; i < num_params; i++)
	{
		if (split_param(params[i], name, value) < 0)
			SKYEYE_ERR("Error: uart has wrong parameter \"%s\".\n", name);

		if (!strncmp("converter", name, strlen(name))) {
			memcpy(&uart_opt.converter[0], value, strlen(value) + 1);
		}

		else if (!strncmp("mod", name, strlen(name))) {
			if (!strncmp ("stdio", value, strlen (value)))
				uart_opt.mod = UART_SIM_STDIO;
			else if (!strncmp ("pipe", value, strlen (value)))
				uart_opt.mod = UART_SIM_PIPE;
			else if (!strncmp ("net", value, strlen (value)))
				uart_opt.mod = UART_SIM_NET;
			else if (!strncmp ("term", value, strlen (value)))
				uart_opt.mod = UART_SIM_TERM;
			else
				fprintf(stderr, "Invalid parameter for mod option\n");
		}

		else if (!strncmp("term_program", name, strlen(name))) {
                        memcpy(&uart_opt.term_program[0], value, strlen(value) + 1);
                }


		/* for old style */
		else if (!strncmp("fd_in", name, strlen(name))) {
			uart_opt.mod = UART_SIM_PIPE;
			memcpy(&uart_opt.desc_in[0], value, strlen(value) + 1);
		} 
		else if (!strncmp("fd_out", name, strlen(name))) {
			uart_opt.mod = UART_SIM_PIPE;
			memcpy(&uart_opt.desc_out[0], value, strlen(value) + 1);
		}

		/* new style */
		else if (!strncmp("desc", name, strlen(name))) {
			only_desc = 1;
			memcpy(&uart_opt.desc_in[0], value, strlen(value) + 1);
			uart_opt.desc_out[0] = '\0';
		} else if (only_desc == 0) {
			if (!strncmp("desc_in", name, strlen(name)))
				memcpy(&uart_opt.desc_in[0], value, strlen(value) + 1);
			else if (!strncmp("desc_out", name, strlen(name)))
				memcpy(&uart_opt.desc_out[0], value, strlen(value) + 1);
		}
		else
			fprintf(stderr, "Invalid option %s for uart", name);
	}

	skyeye_uart_setup(&uart_opt);
	return 0;
}

void skyeye_uart_converter_dcc_setup(struct uart_device *uart_dev){
	fprintf(stderr, "%s not ported yet\n", __FUNCTION__);
}

void uart_register(){
	if(register_option("uart", do_uart_option, "Uart settings") != No_exp)
		fprintf(stderr,"Can not register uart option\n");
	register_uart_operation(uart_read, uart_write);
}
