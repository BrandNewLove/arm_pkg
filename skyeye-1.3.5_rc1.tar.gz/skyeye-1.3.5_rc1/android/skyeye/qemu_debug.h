/* this is a transitional header. It should only be included
 * by non-specific source files. Later, a non-Android specific
 * implementation will be hooked in
 */
#include "android/utils/debug.h"
