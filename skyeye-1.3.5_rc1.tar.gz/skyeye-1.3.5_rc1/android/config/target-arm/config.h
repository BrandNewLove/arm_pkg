/* ARM-specific configuration */
#include "android/config/config.h"

#define TARGET_ARM 1
#define CONFIG_SOFTFLOAT 1
